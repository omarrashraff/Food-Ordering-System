﻿namespace Food_Ordering_Details
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dgvCustomer2 = new System.Windows.Forms.DataGridView();
            this.phoneNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerPhoneBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.appDataSet4 = new Food_Ordering_Details.appDataSet4();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblPassword = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblGoverment = new System.Windows.Forms.Label();
            this.lblCity = new System.Windows.Forms.Label();
            this.lblStreet = new System.Windows.Forms.Label();
            this.lblDistrict = new System.Windows.Forms.Label();
            this.lblPhoneNo = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtGovernment = new System.Windows.Forms.TextBox();
            this.txtDistrict = new System.Windows.Forms.TextBox();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.txtPhoneNo1 = new System.Windows.Forms.TextBox();
            this.txtStreet = new System.Windows.Forms.TextBox();
            this.btnInsert = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnShow = new System.Windows.Forms.Button();
            this.lblPhoneNo2 = new System.Windows.Forms.Label();
            this.txtPhoneNo2 = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.cUSTOMERBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.foodorderingsystemDataSet18 = new Food_Ordering_Details.FoodorderingsystemDataSet18();
            this.dgvCustomer = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.cIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.firstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passwordDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.governmentDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.districtDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.streetDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerBindingSource6 = new System.Windows.Forms.BindingSource(this.components);
            this.appDataSet3 = new Food_Ordering_Details.appDataSet3();
            this.cUSTOMERBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.foodorderingsystemDataSet12 = new Food_Ordering_Details.FoodorderingsystemDataSet12();
            this.cUSTOMERPHONENOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.foodorderingsystemDataSet9 = new Food_Ordering_Details.FoodorderingsystemDataSet9();
            this.cUSTOMERBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.foodorderingsystemDataSet8 = new Food_Ordering_Details.FoodorderingsystemDataSet8();
            this.cUSTOMERTableAdapter = new Food_Ordering_Details.FoodorderingsystemDataSet8TableAdapters.CUSTOMERTableAdapter();
            this.cUSTOMER_PHONENOTableAdapter = new Food_Ordering_Details.FoodorderingsystemDataSet9TableAdapters.CUSTOMER_PHONENOTableAdapter();
            this.foodorderingsystemDataSet10 = new Food_Ordering_Details.FoodorderingsystemDataSet10();
            this.cUSTOMERBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.cUSTOMERTableAdapter1 = new Food_Ordering_Details.FoodorderingsystemDataSet10TableAdapters.CUSTOMERTableAdapter();
            this.foodorderingsystemDataSet11 = new Food_Ordering_Details.FoodorderingsystemDataSet11();
            this.cUSTOMERBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.cUSTOMERTableAdapter2 = new Food_Ordering_Details.FoodorderingsystemDataSet11TableAdapters.CUSTOMERTableAdapter();
            this.cUSTOMERTableAdapter3 = new Food_Ordering_Details.FoodorderingsystemDataSet12TableAdapters.CUSTOMERTableAdapter();
            this.foodorderingsystemDataSet13 = new Food_Ordering_Details.FoodorderingsystemDataSet13();
            this.foodorderingsystemDataSet14 = new Food_Ordering_Details.FoodorderingsystemDataSet14();
            this.foodorderingsystemDataSet15 = new Food_Ordering_Details.FoodorderingsystemDataSet15();
            this.foodorderingsystemDataSet16 = new Food_Ordering_Details.FoodorderingsystemDataSet16();
            this.foodorderingsystemDataSet17 = new Food_Ordering_Details.FoodorderingsystemDataSet17();
            this.cUSTOMERBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.cUSTOMERTableAdapter4 = new Food_Ordering_Details.FoodorderingsystemDataSet17TableAdapters.CUSTOMERTableAdapter();
            this.cUSTOMERTableAdapter5 = new Food_Ordering_Details.FoodorderingsystemDataSet18TableAdapters.CUSTOMERTableAdapter();
            this.foodorderingsystemDataSet19 = new Food_Ordering_Details.FoodorderingsystemDataSet19();
            this.foodorderingsystemDataSet20 = new Food_Ordering_Details.FoodorderingsystemDataSet20();
            this.customerTableAdapter6 = new Food_Ordering_Details.appDataSet3TableAdapters.CustomerTableAdapter();
            this.customerPhoneTableAdapter = new Food_Ordering_Details.appDataSet4TableAdapters.CustomerPhoneTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomer2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerPhoneBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERBindingSource5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERPHONENOBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet20)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvCustomer2
            // 
            this.dgvCustomer2.AutoGenerateColumns = false;
            this.dgvCustomer2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCustomer2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.phoneNoDataGridViewTextBoxColumn});
            this.dgvCustomer2.DataSource = this.customerPhoneBindingSource;
            this.dgvCustomer2.Location = new System.Drawing.Point(1218, 440);
            this.dgvCustomer2.Name = "dgvCustomer2";
            this.dgvCustomer2.RowHeadersWidth = 51;
            this.dgvCustomer2.RowTemplate.Height = 24;
            this.dgvCustomer2.Size = new System.Drawing.Size(187, 240);
            this.dgvCustomer2.TabIndex = 1;
            // 
            // phoneNoDataGridViewTextBoxColumn
            // 
            this.phoneNoDataGridViewTextBoxColumn.DataPropertyName = "PhoneNo";
            this.phoneNoDataGridViewTextBoxColumn.HeaderText = "PhoneNo";
            this.phoneNoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.phoneNoDataGridViewTextBoxColumn.Name = "phoneNoDataGridViewTextBoxColumn";
            this.phoneNoDataGridViewTextBoxColumn.Width = 125;
            // 
            // customerPhoneBindingSource
            // 
            this.customerPhoneBindingSource.DataMember = "CustomerPhone";
            this.customerPhoneBindingSource.DataSource = this.appDataSet4;
            // 
            // appDataSet4
            // 
            this.appDataSet4.DataSetName = "appDataSet4";
            this.appDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.Location = new System.Drawing.Point(59, 158);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(77, 22);
            this.lblEmail.TabIndex = 2;
            this.lblEmail.Text = "EMAIL";
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPassword.Location = new System.Drawing.Point(46, 222);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(120, 22);
            this.lblPassword.TabIndex = 3;
            this.lblPassword.Text = "PASSWORD";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirstName.Location = new System.Drawing.Point(412, 156);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(126, 22);
            this.lblFirstName.TabIndex = 4;
            this.lblFirstName.Text = "FIRSTNAME";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLastName.Location = new System.Drawing.Point(412, 223);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(120, 22);
            this.lblLastName.TabIndex = 5;
            this.lblLastName.Text = "LASTNAME";
            // 
            // lblGoverment
            // 
            this.lblGoverment.AutoSize = true;
            this.lblGoverment.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGoverment.Location = new System.Drawing.Point(403, 286);
            this.lblGoverment.Name = "lblGoverment";
            this.lblGoverment.Size = new System.Drawing.Size(149, 22);
            this.lblGoverment.TabIndex = 6;
            this.lblGoverment.Text = "GOVERNMENT";
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCity.Location = new System.Drawing.Point(786, 163);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(56, 22);
            this.lblCity.TabIndex = 7;
            this.lblCity.Text = "CITY";
            // 
            // lblStreet
            // 
            this.lblStreet.AutoSize = true;
            this.lblStreet.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStreet.Location = new System.Drawing.Point(779, 225);
            this.lblStreet.Name = "lblStreet";
            this.lblStreet.Size = new System.Drawing.Size(87, 22);
            this.lblStreet.TabIndex = 8;
            this.lblStreet.Text = "STREET";
            // 
            // lblDistrict
            // 
            this.lblDistrict.AutoSize = true;
            this.lblDistrict.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDistrict.Location = new System.Drawing.Point(779, 286);
            this.lblDistrict.Name = "lblDistrict";
            this.lblDistrict.Size = new System.Drawing.Size(101, 22);
            this.lblDistrict.TabIndex = 9;
            this.lblDistrict.Text = "DISTRICT";
            // 
            // lblPhoneNo
            // 
            this.lblPhoneNo.AutoSize = true;
            this.lblPhoneNo.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhoneNo.Location = new System.Drawing.Point(46, 289);
            this.lblPhoneNo.Name = "lblPhoneNo";
            this.lblPhoneNo.Size = new System.Drawing.Size(107, 22);
            this.lblPhoneNo.TabIndex = 10;
            this.lblPhoneNo.Text = "PHONENO";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(209, 158);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(100, 22);
            this.txtEmail.TabIndex = 11;
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(209, 222);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(100, 22);
            this.txtPassword.TabIndex = 12;
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(560, 158);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(100, 22);
            this.txtFirstName.TabIndex = 13;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(560, 225);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(100, 22);
            this.txtLastName.TabIndex = 14;
            // 
            // txtGovernment
            // 
            this.txtGovernment.Location = new System.Drawing.Point(560, 286);
            this.txtGovernment.Name = "txtGovernment";
            this.txtGovernment.Size = new System.Drawing.Size(100, 22);
            this.txtGovernment.TabIndex = 15;
            // 
            // txtDistrict
            // 
            this.txtDistrict.Location = new System.Drawing.Point(910, 284);
            this.txtDistrict.Name = "txtDistrict";
            this.txtDistrict.Size = new System.Drawing.Size(100, 22);
            this.txtDistrict.TabIndex = 16;
            // 
            // txtCity
            // 
            this.txtCity.Location = new System.Drawing.Point(910, 163);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(100, 22);
            this.txtCity.TabIndex = 17;
            // 
            // txtPhoneNo1
            // 
            this.txtPhoneNo1.Location = new System.Drawing.Point(209, 289);
            this.txtPhoneNo1.Name = "txtPhoneNo1";
            this.txtPhoneNo1.Size = new System.Drawing.Size(100, 22);
            this.txtPhoneNo1.TabIndex = 18;
            // 
            // txtStreet
            // 
            this.txtStreet.Location = new System.Drawing.Point(910, 225);
            this.txtStreet.Name = "txtStreet";
            this.txtStreet.Size = new System.Drawing.Size(100, 22);
            this.txtStreet.TabIndex = 20;
            // 
            // btnInsert
            // 
            this.btnInsert.Location = new System.Drawing.Point(194, 350);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(147, 51);
            this.btnInsert.TabIndex = 21;
            this.btnInsert.Text = "INSERT";
            this.btnInsert.UseVisualStyleBackColor = true;
            this.btnInsert.Click += new System.EventHandler(this.btnInsert_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(500, 352);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(147, 49);
            this.btnUpdate.TabIndex = 22;
            this.btnUpdate.Text = "UPDATE";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(790, 352);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(147, 51);
            this.btnDelete.TabIndex = 23;
            this.btnDelete.Text = "DELETE";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(231, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(927, 123);
            this.label1.TabIndex = 24;
            this.label1.Text = "ACCOUNT INFO ";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnShow
            // 
            this.btnShow.Location = new System.Drawing.Point(1050, 352);
            this.btnShow.Name = "btnShow";
            this.btnShow.Size = new System.Drawing.Size(146, 51);
            this.btnShow.TabIndex = 25;
            this.btnShow.Text = "SHOW DATA";
            this.btnShow.UseVisualStyleBackColor = true;
            this.btnShow.Click += new System.EventHandler(this.btnShow_Click);
            // 
            // lblPhoneNo2
            // 
            this.lblPhoneNo2.AutoSize = true;
            this.lblPhoneNo2.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPhoneNo2.Location = new System.Drawing.Point(1095, 225);
            this.lblPhoneNo2.Name = "lblPhoneNo2";
            this.lblPhoneNo2.Size = new System.Drawing.Size(116, 22);
            this.lblPhoneNo2.TabIndex = 26;
            this.lblPhoneNo2.Text = "PHONENO2";
            // 
            // txtPhoneNo2
            // 
            this.txtPhoneNo2.Location = new System.Drawing.Point(1244, 222);
            this.txtPhoneNo2.Name = "txtPhoneNo2";
            this.txtPhoneNo2.Size = new System.Drawing.Size(120, 22);
            this.txtPhoneNo2.TabIndex = 27;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.DataSource = this.cUSTOMERBindingSource5;
            this.dataGridView1.Location = new System.Drawing.Point(63, 444);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1184, 240);
            this.dataGridView1.TabIndex = 28;
            // 
            // cUSTOMERBindingSource5
            // 
            this.cUSTOMERBindingSource5.DataMember = "CUSTOMER";
            this.cUSTOMERBindingSource5.DataSource = this.foodorderingsystemDataSet18;
            // 
            // foodorderingsystemDataSet18
            // 
            this.foodorderingsystemDataSet18.DataSetName = "FoodorderingsystemDataSet18";
            this.foodorderingsystemDataSet18.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dgvCustomer
            // 
            this.dgvCustomer.AutoGenerateColumns = false;
            this.dgvCustomer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCustomer.DataSource = this.cUSTOMERBindingSource5;
            this.dgvCustomer.Location = new System.Drawing.Point(63, 444);
            this.dgvCustomer.Name = "dgvCustomer";
            this.dgvCustomer.RowHeadersWidth = 51;
            this.dgvCustomer.RowTemplate.Height = 24;
            this.dgvCustomer.Size = new System.Drawing.Size(1184, 240);
            this.dgvCustomer.TabIndex = 28;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cIDDataGridViewTextBoxColumn,
            this.firstNameDataGridViewTextBoxColumn,
            this.lastNameDataGridViewTextBoxColumn,
            this.emailDataGridViewTextBoxColumn,
            this.passwordDataGridViewTextBoxColumn,
            this.governmentDataGridViewTextBoxColumn,
            this.cityDataGridViewTextBoxColumn,
            this.districtDataGridViewTextBoxColumn,
            this.streetDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.customerBindingSource6;
            this.dataGridView2.Location = new System.Drawing.Point(36, 440);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(1221, 240);
            this.dataGridView2.TabIndex = 28;
            // 
            // cIDDataGridViewTextBoxColumn
            // 
            this.cIDDataGridViewTextBoxColumn.DataPropertyName = "CID";
            this.cIDDataGridViewTextBoxColumn.HeaderText = "CID";
            this.cIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.cIDDataGridViewTextBoxColumn.Name = "cIDDataGridViewTextBoxColumn";
            this.cIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.cIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // firstNameDataGridViewTextBoxColumn
            // 
            this.firstNameDataGridViewTextBoxColumn.DataPropertyName = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.HeaderText = "FirstName";
            this.firstNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.firstNameDataGridViewTextBoxColumn.Name = "firstNameDataGridViewTextBoxColumn";
            this.firstNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // lastNameDataGridViewTextBoxColumn
            // 
            this.lastNameDataGridViewTextBoxColumn.DataPropertyName = "LastName";
            this.lastNameDataGridViewTextBoxColumn.HeaderText = "LastName";
            this.lastNameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.lastNameDataGridViewTextBoxColumn.Name = "lastNameDataGridViewTextBoxColumn";
            this.lastNameDataGridViewTextBoxColumn.Width = 125;
            // 
            // emailDataGridViewTextBoxColumn
            // 
            this.emailDataGridViewTextBoxColumn.DataPropertyName = "Email";
            this.emailDataGridViewTextBoxColumn.HeaderText = "Email";
            this.emailDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.emailDataGridViewTextBoxColumn.Name = "emailDataGridViewTextBoxColumn";
            this.emailDataGridViewTextBoxColumn.Width = 125;
            // 
            // passwordDataGridViewTextBoxColumn
            // 
            this.passwordDataGridViewTextBoxColumn.DataPropertyName = "Password";
            this.passwordDataGridViewTextBoxColumn.HeaderText = "Password";
            this.passwordDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.passwordDataGridViewTextBoxColumn.Name = "passwordDataGridViewTextBoxColumn";
            this.passwordDataGridViewTextBoxColumn.Width = 125;
            // 
            // governmentDataGridViewTextBoxColumn
            // 
            this.governmentDataGridViewTextBoxColumn.DataPropertyName = "Government";
            this.governmentDataGridViewTextBoxColumn.HeaderText = "Government";
            this.governmentDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.governmentDataGridViewTextBoxColumn.Name = "governmentDataGridViewTextBoxColumn";
            this.governmentDataGridViewTextBoxColumn.Width = 125;
            // 
            // cityDataGridViewTextBoxColumn
            // 
            this.cityDataGridViewTextBoxColumn.DataPropertyName = "City";
            this.cityDataGridViewTextBoxColumn.HeaderText = "City";
            this.cityDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.cityDataGridViewTextBoxColumn.Name = "cityDataGridViewTextBoxColumn";
            this.cityDataGridViewTextBoxColumn.Width = 125;
            // 
            // districtDataGridViewTextBoxColumn
            // 
            this.districtDataGridViewTextBoxColumn.DataPropertyName = "District";
            this.districtDataGridViewTextBoxColumn.HeaderText = "District";
            this.districtDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.districtDataGridViewTextBoxColumn.Name = "districtDataGridViewTextBoxColumn";
            this.districtDataGridViewTextBoxColumn.Width = 125;
            // 
            // streetDataGridViewTextBoxColumn
            // 
            this.streetDataGridViewTextBoxColumn.DataPropertyName = "Street";
            this.streetDataGridViewTextBoxColumn.HeaderText = "Street";
            this.streetDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.streetDataGridViewTextBoxColumn.Name = "streetDataGridViewTextBoxColumn";
            this.streetDataGridViewTextBoxColumn.Width = 125;
            // 
            // customerBindingSource6
            // 
            this.customerBindingSource6.DataMember = "Customer";
            this.customerBindingSource6.DataSource = this.appDataSet3;
            // 
            // appDataSet3
            // 
            this.appDataSet3.DataSetName = "appDataSet3";
            this.appDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cUSTOMERBindingSource3
            // 
            this.cUSTOMERBindingSource3.DataMember = "CUSTOMER";
            this.cUSTOMERBindingSource3.DataSource = this.foodorderingsystemDataSet12;
            // 
            // foodorderingsystemDataSet12
            // 
            this.foodorderingsystemDataSet12.DataSetName = "FoodorderingsystemDataSet12";
            this.foodorderingsystemDataSet12.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cUSTOMERPHONENOBindingSource
            // 
            this.cUSTOMERPHONENOBindingSource.DataMember = "CUSTOMER_PHONENO";
            this.cUSTOMERPHONENOBindingSource.DataSource = this.foodorderingsystemDataSet9;
            // 
            // foodorderingsystemDataSet9
            // 
            this.foodorderingsystemDataSet9.DataSetName = "FoodorderingsystemDataSet9";
            this.foodorderingsystemDataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cUSTOMERBindingSource
            // 
            this.cUSTOMERBindingSource.DataMember = "CUSTOMER";
            this.cUSTOMERBindingSource.DataSource = this.foodorderingsystemDataSet8;
            // 
            // foodorderingsystemDataSet8
            // 
            this.foodorderingsystemDataSet8.DataSetName = "FoodorderingsystemDataSet8";
            this.foodorderingsystemDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cUSTOMERTableAdapter
            // 
            this.cUSTOMERTableAdapter.ClearBeforeFill = true;
            // 
            // cUSTOMER_PHONENOTableAdapter
            // 
            this.cUSTOMER_PHONENOTableAdapter.ClearBeforeFill = true;
            // 
            // foodorderingsystemDataSet10
            // 
            this.foodorderingsystemDataSet10.DataSetName = "FoodorderingsystemDataSet10";
            this.foodorderingsystemDataSet10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cUSTOMERBindingSource1
            // 
            this.cUSTOMERBindingSource1.DataMember = "CUSTOMER";
            this.cUSTOMERBindingSource1.DataSource = this.foodorderingsystemDataSet10;
            // 
            // cUSTOMERTableAdapter1
            // 
            this.cUSTOMERTableAdapter1.ClearBeforeFill = true;
            // 
            // foodorderingsystemDataSet11
            // 
            this.foodorderingsystemDataSet11.DataSetName = "FoodorderingsystemDataSet11";
            this.foodorderingsystemDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cUSTOMERBindingSource2
            // 
            this.cUSTOMERBindingSource2.DataMember = "CUSTOMER";
            this.cUSTOMERBindingSource2.DataSource = this.foodorderingsystemDataSet11;
            // 
            // cUSTOMERTableAdapter2
            // 
            this.cUSTOMERTableAdapter2.ClearBeforeFill = true;
            // 
            // cUSTOMERTableAdapter3
            // 
            this.cUSTOMERTableAdapter3.ClearBeforeFill = true;
            // 
            // foodorderingsystemDataSet13
            // 
            this.foodorderingsystemDataSet13.DataSetName = "FoodorderingsystemDataSet13";
            this.foodorderingsystemDataSet13.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // foodorderingsystemDataSet14
            // 
            this.foodorderingsystemDataSet14.DataSetName = "FoodorderingsystemDataSet14";
            this.foodorderingsystemDataSet14.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // foodorderingsystemDataSet15
            // 
            this.foodorderingsystemDataSet15.DataSetName = "FoodorderingsystemDataSet15";
            this.foodorderingsystemDataSet15.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // foodorderingsystemDataSet16
            // 
            this.foodorderingsystemDataSet16.DataSetName = "FoodorderingsystemDataSet16";
            this.foodorderingsystemDataSet16.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // foodorderingsystemDataSet17
            // 
            this.foodorderingsystemDataSet17.DataSetName = "FoodorderingsystemDataSet17";
            this.foodorderingsystemDataSet17.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cUSTOMERBindingSource4
            // 
            this.cUSTOMERBindingSource4.DataMember = "CUSTOMER";
            this.cUSTOMERBindingSource4.DataSource = this.foodorderingsystemDataSet17;
            // 
            // cUSTOMERTableAdapter4
            // 
            this.cUSTOMERTableAdapter4.ClearBeforeFill = true;
            // 
            // cUSTOMERTableAdapter5
            // 
            this.cUSTOMERTableAdapter5.ClearBeforeFill = true;
            // 
            // foodorderingsystemDataSet19
            // 
            this.foodorderingsystemDataSet19.DataSetName = "FoodorderingsystemDataSet19";
            this.foodorderingsystemDataSet19.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // foodorderingsystemDataSet20
            // 
            this.foodorderingsystemDataSet20.DataSetName = "FoodorderingsystemDataSet20";
            this.foodorderingsystemDataSet20.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // customerTableAdapter6
            // 
            this.customerTableAdapter6.ClearBeforeFill = true;
            // 
            // customerPhoneTableAdapter
            // 
            this.customerPhoneTableAdapter.ClearBeforeFill = true;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1438, 710);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.txtPhoneNo2);
            this.Controls.Add(this.lblPhoneNo2);
            this.Controls.Add(this.btnShow);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnInsert);
            this.Controls.Add(this.txtStreet);
            this.Controls.Add(this.txtPhoneNo1);
            this.Controls.Add(this.txtCity);
            this.Controls.Add(this.txtDistrict);
            this.Controls.Add(this.txtGovernment);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(this.txtFirstName);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.lblPhoneNo);
            this.Controls.Add(this.lblDistrict);
            this.Controls.Add(this.lblStreet);
            this.Controls.Add(this.lblCity);
            this.Controls.Add(this.lblGoverment);
            this.Controls.Add(this.lblLastName);
            this.Controls.Add(this.lblFirstName);
            this.Controls.Add(this.lblPassword);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.dgvCustomer2);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomer2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerPhoneBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERBindingSource5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERPHONENOBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cUSTOMERBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet20)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private FoodorderingsystemDataSet8 foodorderingsystemDataSet8;
        private System.Windows.Forms.BindingSource cUSTOMERBindingSource;
        private FoodorderingsystemDataSet8TableAdapters.CUSTOMERTableAdapter cUSTOMERTableAdapter;
        private FoodorderingsystemDataSet9 foodorderingsystemDataSet9;
        private System.Windows.Forms.BindingSource cUSTOMERPHONENOBindingSource;
        private FoodorderingsystemDataSet9TableAdapters.CUSTOMER_PHONENOTableAdapter cUSTOMER_PHONENOTableAdapter;
        private System.Windows.Forms.DataGridView dgvCustomer2;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblGoverment;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.Label lblStreet;
        private System.Windows.Forms.Label lblDistrict;
        private System.Windows.Forms.Label lblPhoneNo;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtGovernment;
        private System.Windows.Forms.TextBox txtDistrict;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.TextBox txtPhoneNo1;
        private System.Windows.Forms.TextBox txtStreet;
        private System.Windows.Forms.Button btnInsert;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnShow;
        private System.Windows.Forms.Label lblPhoneNo2;
        private System.Windows.Forms.TextBox txtPhoneNo2;
        private FoodorderingsystemDataSet10 foodorderingsystemDataSet10;
        private System.Windows.Forms.BindingSource cUSTOMERBindingSource1;
        private FoodorderingsystemDataSet10TableAdapters.CUSTOMERTableAdapter cUSTOMERTableAdapter1;
        private FoodorderingsystemDataSet11 foodorderingsystemDataSet11;
        private System.Windows.Forms.BindingSource cUSTOMERBindingSource2;
        private FoodorderingsystemDataSet11TableAdapters.CUSTOMERTableAdapter cUSTOMERTableAdapter2;
        private FoodorderingsystemDataSet12 foodorderingsystemDataSet12;
        private System.Windows.Forms.BindingSource cUSTOMERBindingSource3;
        private FoodorderingsystemDataSet12TableAdapters.CUSTOMERTableAdapter cUSTOMERTableAdapter3;
        private FoodorderingsystemDataSet13 foodorderingsystemDataSet13;
        private FoodorderingsystemDataSet14 foodorderingsystemDataSet14;
        private FoodorderingsystemDataSet15 foodorderingsystemDataSet15;
        private FoodorderingsystemDataSet16 foodorderingsystemDataSet16;
        private FoodorderingsystemDataSet17 foodorderingsystemDataSet17;
        private System.Windows.Forms.BindingSource cUSTOMERBindingSource4;
        private FoodorderingsystemDataSet17TableAdapters.CUSTOMERTableAdapter cUSTOMERTableAdapter4;
        private FoodorderingsystemDataSet18TableAdapters.CUSTOMERTableAdapter cUSTOMERTableAdapter5;
        private System.Windows.Forms.BindingSource cUSTOMERBindingSource5;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dgvCustomer;
        private FoodorderingsystemDataSet19 foodorderingsystemDataSet19;
        private System.Windows.Forms.DataGridView dataGridView2;
        private FoodorderingsystemDataSet20 foodorderingsystemDataSet20;
        private FoodorderingsystemDataSet18 foodorderingsystemDataSet18;
        private appDataSet3 appDataSet3;
        private System.Windows.Forms.BindingSource customerBindingSource6;
        private appDataSet3TableAdapters.CustomerTableAdapter customerTableAdapter6;
        private System.Windows.Forms.DataGridViewTextBoxColumn cIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn passwordDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn governmentDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn districtDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn streetDataGridViewTextBoxColumn;
        private appDataSet4 appDataSet4;
        private System.Windows.Forms.BindingSource customerPhoneBindingSource;
        private appDataSet4TableAdapters.CustomerPhoneTableAdapter customerPhoneTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn phoneNoDataGridViewTextBoxColumn;
    }
}