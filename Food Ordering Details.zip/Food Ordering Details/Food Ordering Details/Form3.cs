﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Xml.Linq;
using System.Text.RegularExpressions;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Food_Ordering_Details
{
    public partial class Form3 : Form
    {

        
        private void Form3_Load(object sender, EventArgs e)
        {




        }



        private void btnShow_Click(object sender, EventArgs e)
        {

            try
            {
                using (SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=app;Integrated Security=True"))
                {
                    con.Open();

                    // Load Customer data
                    using (SqlDataAdapter customerAdapter = new SqlDataAdapter("SELECT * FROM Customer", con))
                    {
                        DataTable customerTable = new DataTable();
                        customerAdapter.Fill(customerTable);
                        dataGridView2.DataSource = customerTable;
                    }

                    // Load CustomerPhone data
                    using (SqlDataAdapter phoneAdapter = new SqlDataAdapter("SELECT * FROM CustomerPhone", con))
                    {
                        DataTable phoneTable = new DataTable();
                        phoneAdapter.Fill(phoneTable);
                        dgvCustomer2.DataSource = phoneTable;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please enter both Email and Password.", "Input Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=app;Integrated Security=True"))
                {
                    con.Open();

                    // Step 1: Verify customer exists with matching email and password
                    int customerId = -1;
                    using (SqlCommand checkCmd = new SqlCommand("SELECT CID FROM Customer WHERE Email = @Email AND Password = @Password", con))
                    {
                        checkCmd.Parameters.AddWithValue("@Email", email);
                        checkCmd.Parameters.AddWithValue("@Password", password);

                        object result = checkCmd.ExecuteScalar();
                        if (result == null)
                        {
                            MessageBox.Show("No customer found with the provided email and password.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }
                        customerId = Convert.ToInt32(result);
                    }

                    // Step 2: Confirm deletion from user
                    DialogResult confirm = MessageBox.Show("Are you sure you want to delete this customer and all related data?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (confirm != DialogResult.Yes)
                        return;

                    // Step 3: Delete phone numbers first due to foreign key constraint
                    using (SqlCommand deletePhonesCmd = new SqlCommand("DELETE FROM CustomerPhone WHERE CID = @CID", con))
                    {
                        deletePhonesCmd.Parameters.AddWithValue("@CID", customerId);
                        deletePhonesCmd.ExecuteNonQuery();
                    }

                    // Step 4: Delete customer
                    using (SqlCommand deleteCustomerCmd = new SqlCommand("DELETE FROM Customer WHERE CID = @CID", con))
                    {
                        deleteCustomerCmd.Parameters.AddWithValue("@CID", customerId);
                        deleteCustomerCmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Customer and all related data deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Optional: Refresh UI
                    btnShow_Click(null, null);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while deleting: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {

                using (SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=app;Integrated Security=True"))
                {
                    con.Open();


                    using (SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM CUSTOMER WHERE EMAIL = @Email", con))
                    {
                        checkCmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                        int emailCount = (int)checkCmd.ExecuteScalar();

                        if (emailCount > 0)
                        {
                            MessageBox.Show("This email is already registered. Please use a different email.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }


                    List<string> newPhoneNumbers = new List<string>();
                    if (!string.IsNullOrWhiteSpace(txtPhoneNo1.Text)) newPhoneNumbers.Add(txtPhoneNo1.Text.Trim());
                    if (!string.IsNullOrWhiteSpace(txtPhoneNo2.Text)) newPhoneNumbers.Add(txtPhoneNo2.Text.Trim());


                    if (newPhoneNumbers.Count == 0)
                    {
                        MessageBox.Show("A customer must provide at least one phone number. Please enter at least one phone number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }


                    if (newPhoneNumbers.Count > 2)
                    {
                        MessageBox.Show("A customer can have at most 2 phone numbers. Please provide only one or two phone numbers.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }


                    int customerId;
                    using (SqlCommand cmd = new SqlCommand(
                    "INSERT INTO CUSTOMER (EMAIL, PASSWORD, FIRSTNAME, LASTNAME, GOVERNMENT, CITY, STREET, DISTRICT) " +
                    "OUTPUT INSERTED.CID VALUES (@Email, @Password, @FirstName, @LastName, @Government, @City, @Street, @District)", con))
                    {
                        cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                        cmd.Parameters.AddWithValue("@Password", txtPassword.Text);
                        cmd.Parameters.AddWithValue("@FirstName", txtFirstName.Text);
                        cmd.Parameters.AddWithValue("@LastName", txtLastName.Text);
                        cmd.Parameters.AddWithValue("@Government", txtGovernment.Text);
                        cmd.Parameters.AddWithValue("@City", txtCity.Text);
                        cmd.Parameters.AddWithValue("@Street", txtStreet.Text);
                        cmd.Parameters.AddWithValue("@District", txtDistrict.Text);
                        object result = cmd.ExecuteScalar();

                        customerId = Convert.ToInt32(result);
                        MessageBox.Show("Customer inserted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }


                    using (SqlCommand phoneCmd = new SqlCommand("INSERT INTO CustomerPhone (CID, PhoneNo) VALUES (@CustomerID, @PhoneNumber)", con))
                    {
                        phoneCmd.Parameters.AddWithValue("@CustomerID", customerId);
                        phoneCmd.Parameters.Add("@PhoneNumber", SqlDbType.VarChar);

                        foreach (string phoneNumber in newPhoneNumbers)
                        {
                            try
                            {
                                phoneCmd.Parameters["@PhoneNumber"].Value = phoneNumber;
                                phoneCmd.ExecuteNonQuery();
                            }
                            catch (SqlException ex) when (ex.Number == 2627)
                            {
                                MessageBox.Show($"The phone number '{phoneNumber}' is already associated with this customer. Please use a different phone number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                continue;
                            }
                        }
                    }
                    MessageBox.Show("Phone numbers inserted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    RefreshTable(txtEmail.Text);


                    con.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

            private void RefreshTable(string email)
        {
            try
            {
                if (DesignMode) return; // Prevent execution in design mode

                using (SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=app;Integrated Security=True"))
                {
                    con.Open();
                    // Join CUSTOMER and CUSTOMER_PHONENO tables to display customer details and phone numbers
                    using (SqlDataAdapter da = new SqlDataAdapter(
                        "SELECT C.*, P.PhoneNo  " +
                        "FROM CUSTOMER C " +
                        "LEFT JOIN CustomerPhone  P ON C.CID = P.CID " +
                        "WHERE C.EMAIL = @Email", con))
                    {
                        da.SelectCommand.Parameters.AddWithValue("@Email", email);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dgvCustomer.DataSource = dt; // Assuming dataGridView1 is the name of your DataGridView
                    }
                    con.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while refreshing the table: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }



        private void label1_Click(object sender, EventArgs e)
        {

        }


        



        private string Password { get; set; } = "";
        private string Email { get; set; } = "";
        private string FirstName { get; set; } = "";
        private string LastName { get; set; } = "";
        private string Government { get; set; } = "";
        private string City { get; set; } = "";
        private string Street { get; set; } = "";
        private string District { get; set; } = "";
        private string PhoneNo1 { get; set; } = "";
        private string PhoneNo2 { get; set; } = "";

        public Form3 ()
        {
            InitializeComponent();
            btnUpdate.Enabled = true;
            txtEmail.TextChanged += InputFields_TextChanged;
            txtPassword.TextChanged += InputFields_TextChanged;
            txtFirstName.TextChanged += InputFields_TextChanged;
            txtLastName.TextChanged += InputFields_TextChanged;
            txtGovernment.TextChanged += InputFields_TextChanged;
            txtCity.TextChanged += InputFields_TextChanged;
            txtStreet.TextChanged += InputFields_TextChanged;
            txtDistrict.TextChanged += InputFields_TextChanged;
            txtPhoneNo1.TextChanged += InputFields_TextChanged;
            txtPhoneNo2.TextChanged += InputFields_TextChanged;
        }

        private void InputFields_TextChanged(object sender, EventArgs e)
        {
            btnUpdate.Enabled = IsAnyFieldChanged();
        }

        private bool IsAnyFieldChanged()
        {
            return txtEmail.Text.Trim() != Email ||
                   txtPassword.Text != Password ||
                   txtFirstName.Text.Trim() != FirstName ||
                   txtLastName.Text.Trim() != LastName ||
                   txtGovernment.Text.Trim() != Government ||
                   txtCity.Text.Trim() != City ||
                   txtStreet.Text.Trim() != Street ||
                   txtDistrict.Text.Trim() != District ||
                   txtPhoneNo1.Text.Trim() != PhoneNo1 ||
                   txtPhoneNo2.Text.Trim() != PhoneNo2;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                string email = txtEmail.Text.Trim();
                string inputPassword = txtPassword.Text.Trim();

                if (string.IsNullOrWhiteSpace(email))
                {
                    MessageBox.Show("Please enter the Email.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                using (SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=app;Integrated Security=True"))
                {
                    con.Open();

                    // Try to find customer using just the email
                    SqlCommand getCmd = new SqlCommand(
                        "SELECT c.*, " +
                        "MIN(p.PhoneNo) AS Phone1, " +
                        "MAX(p.PhoneNo) AS Phone2 " +
                        "FROM Customer c " +
                        "LEFT JOIN CustomerPhone p ON c.CID = p.CID " +
                        "WHERE c.Email = @Email " +
                        "GROUP BY c.CID, c.FirstName, c.LastName, c.Password, c.Government, c.City, c.Street, c.District, c.Email", con);
                    getCmd.Parameters.AddWithValue("@Email", email);

                    SqlDataAdapter adapter = new SqlDataAdapter(getCmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    if (dt.Rows.Count == 0)
                    {
                        MessageBox.Show("No customer found with this email.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    DataRow original = dt.Rows[0];
                    int customerId = Convert.ToInt32(original["CID"]);
                    string originalPassword = original["Password"].ToString();

                    // === CASE 1: Password update only ===
                    bool isPasswordChangeOnly = !string.IsNullOrWhiteSpace(inputPassword)
                        && inputPassword != originalPassword
                        && AllOtherFieldsEmpty();

                    if (isPasswordChangeOnly)
                    {
                        SqlCommand updatePwdCmd = new SqlCommand("UPDATE Customer SET Password = @Password WHERE Email = @Email", con);
                        updatePwdCmd.Parameters.AddWithValue("@Password", inputPassword);
                        updatePwdCmd.Parameters.AddWithValue("@Email", email);
                        updatePwdCmd.ExecuteNonQuery();

                        MessageBox.Show("Password updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    // === CASE 2: Update other fields ===
                    if (string.IsNullOrWhiteSpace(inputPassword) || inputPassword != originalPassword)
                    {
                        MessageBox.Show("To update personal info, please enter the correct current password.", "Authentication Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    // Get updated values (or fallback to original)
                    string newPassword = (txtPassword.Text == originalPassword || string.IsNullOrWhiteSpace(txtPassword.Text)) ? originalPassword : txtPassword.Text;
                    string newFirstName = string.IsNullOrWhiteSpace(txtFirstName.Text) ? original["FirstName"].ToString() : txtFirstName.Text;
                    string newLastName = string.IsNullOrWhiteSpace(txtLastName.Text) ? original["LastName"].ToString() : txtLastName.Text;
                    string newGovernment = string.IsNullOrWhiteSpace(txtGovernment.Text) ? original["Government"].ToString() : txtGovernment.Text;
                    string newCity = string.IsNullOrWhiteSpace(txtCity.Text) ? original["City"].ToString() : txtCity.Text;
                    string newStreet = string.IsNullOrWhiteSpace(txtStreet.Text) ? original["Street"].ToString() : txtStreet.Text;
                    string newDistrict = string.IsNullOrWhiteSpace(txtDistrict.Text) ? original["District"].ToString() : txtDistrict.Text;

                    if (MessageBox.Show("Confirm update?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                        return;

                    SqlCommand updateCmd = new SqlCommand(
                        "UPDATE Customer SET Password=@Password, FirstName=@FirstName, LastName=@LastName, Government=@Government, City=@City, Street=@Street, District=@District WHERE CID=@CID", con);
                    updateCmd.Parameters.AddWithValue("@Password", newPassword);
                    updateCmd.Parameters.AddWithValue("@FirstName", newFirstName);
                    updateCmd.Parameters.AddWithValue("@LastName", newLastName);
                    updateCmd.Parameters.AddWithValue("@Government", newGovernment);
                    updateCmd.Parameters.AddWithValue("@City", newCity);
                    updateCmd.Parameters.AddWithValue("@Street", newStreet);
                    updateCmd.Parameters.AddWithValue("@District", newDistrict);
                    updateCmd.Parameters.AddWithValue("@CID", customerId);
                    updateCmd.ExecuteNonQuery();

                    // Update phone numbers
                    bool hasPhone1 = !string.IsNullOrWhiteSpace(txtPhoneNo1.Text);
                    bool hasPhone2 = !string.IsNullOrWhiteSpace(txtPhoneNo2.Text);

                    if (hasPhone1 || hasPhone2)
                    {
                        new SqlCommand("DELETE FROM CustomerPhone WHERE CID=@CID", con) { Parameters = { new SqlParameter("@CID", customerId) } }.ExecuteNonQuery();

                        SqlCommand insertPhone = new SqlCommand("INSERT INTO CustomerPhone (CID, PhoneNo) VALUES (@CID, @PhoneNo)", con);
                        insertPhone.Parameters.Add("@CID", SqlDbType.Int).Value = customerId;
                        insertPhone.Parameters.Add("@PhoneNo", SqlDbType.VarChar);

                        if (hasPhone1)
                        {
                            insertPhone.Parameters["@PhoneNo"].Value = txtPhoneNo1.Text.Trim();
                            insertPhone.ExecuteNonQuery();
                        }

                        if (hasPhone2)
                        {
                            insertPhone.Parameters["@PhoneNo"].Value = txtPhoneNo2.Text.Trim();
                            insertPhone.ExecuteNonQuery();
                        }
                    }

                    MessageBox.Show("Customer updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    btnShow_Click(null, null);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

private bool AllOtherFieldsEmpty()
        {
            return string.IsNullOrWhiteSpace(txtFirstName.Text)
                && string.IsNullOrWhiteSpace(txtLastName.Text)
                && string.IsNullOrWhiteSpace(txtGovernment.Text)
                && string.IsNullOrWhiteSpace(txtCity.Text)
                && string.IsNullOrWhiteSpace(txtStreet.Text)
                && string.IsNullOrWhiteSpace(txtDistrict.Text)
                && string.IsNullOrWhiteSpace(txtPhoneNo1.Text)
                && string.IsNullOrWhiteSpace(txtPhoneNo2.Text);
        }
    }
    }






    

    

    
    
