﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Food_Ordering_Details
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'appDataSet8.Feedback' table. You can move, or remove it, as needed.
            this.feedbackTableAdapter6.Fill(this.appDataSet8.Feedback);
            // TODO: This line of code loads data into the 'appDataSet7.Feedback' table. You can move, or remove it, as needed.
            this.feedbackTableAdapter5.Fill(this.appDataSet7.Feedback);
            // TODO: This line of code loads data into the 'appDataSet6.Feedback' table. You can move, or remove it, as needed.
            this.feedbackTableAdapter4.Fill(this.appDataSet6.Feedback);




        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Show();

        }

      
        private void btnShow_Click(object sender, EventArgs e)
        {

            

            try
            {
                if (string.IsNullOrWhiteSpace(txtEmail.Text))
                {
                    MessageBox.Show("Please enter an email.", "Input Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                using (SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=app;Integrated Security=True"))
                {
                    con.Open();

                    // Get CID from email
                    int customerId;
                    using (SqlCommand getCustomerCmd = new SqlCommand("SELECT CID FROM CUSTOMER WHERE EMAIL = @Email", con))
                    {
                        getCustomerCmd.Parameters.Add("@Email", SqlDbType.NVarChar).Value = txtEmail.Text;
                        object result = getCustomerCmd.ExecuteScalar();

                        if (result == null)
                        {
                            MessageBox.Show("Email not found in the database.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }

                        customerId = Convert.ToInt32(result);
                    }

                    // Fetch Feedbacks related to CID, excluding CID but including FeedbackID
                    using (SqlDataAdapter da = new SqlDataAdapter(
                        "SELECT FeedbackID, MealID, Rating, Comment FROM FEEDBACK WHERE CID = @CID", con))
                    {
                        da.SelectCommand.Parameters.Add("@CID", SqlDbType.Int).Value = customerId;
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dgvFeedback.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading feedback data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            try
            {
                
                if (string.IsNullOrWhiteSpace(txtEmail.Text) ||
                    string.IsNullOrWhiteSpace(txtMealId.Text) ||
                    string.IsNullOrWhiteSpace(txtRating.Text))
                {
                    MessageBox.Show("All fields are required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (!int.TryParse(txtMealId.Text, out int mealId) || mealId <= 0)
                {
                    MessageBox.Show("Please enter a valid Meal ID.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (!int.TryParse(txtRating.Text, out int rating) || rating < 1 || rating > 5)
                {
                    MessageBox.Show("Please enter a valid rating (1-5).", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                using (SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=app;Integrated Security=True"))
                {
                    con.Open();

                    
                    using (SqlCommand checkMealCmd = new SqlCommand("SELECT COUNT(*) FROM Meal WHERE MealID = @MealID", con))
                    {
                        checkMealCmd.Parameters.Add("@MealID", SqlDbType.Int).Value = mealId;
                        int mealCount = (int)checkMealCmd.ExecuteScalar();
                        if (mealCount == 0)
                        {
                            MessageBox.Show("The Meal ID does not exist. Please enter a valid Meal ID.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }

                    int customerId;
                    using (SqlCommand getCustomerCmd = new SqlCommand("SELECT CID FROM CUSTOMER WHERE EMAIL = @Email", con))
                    {
                        getCustomerCmd.Parameters.Add("@Email", SqlDbType.NVarChar).Value = txtEmail.Text;
                        object result = getCustomerCmd.ExecuteScalar();

                        if (result == null)
                        {
                            MessageBox.Show("This email is invalid. Please use a different email.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                        customerId = Convert.ToInt32(result);
                    }

                    using (SqlCommand cmd = new SqlCommand(
                        "INSERT INTO FEEDBACK (CID, MealID, Rating, Comment) VALUES (@CID, @MealID, @Rating, @Comment)", con))
                    {
                        cmd.Parameters.Add("@CID", SqlDbType.Int).Value = customerId;
                        cmd.Parameters.Add("@MealID", SqlDbType.Int).Value = mealId;
                        cmd.Parameters.Add("@Rating", SqlDbType.Int).Value = rating;
                        cmd.Parameters.Add("@Comment", SqlDbType.NVarChar).Value = txtComment.Text ?? (object)DBNull.Value;
                        cmd.ExecuteNonQuery();

                        MessageBox.Show("Feedback inserted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    RefreeshTable(customerId);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An unexpected error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void RefreeshTable(int customerId)
        {
            try
            {
                if (DesignMode) return;

                using (SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=app;Integrated Security=True"))
                {
                    con.Open();

                    using (SqlDataAdapter da = new SqlDataAdapter(
                        "SELECT F.MealID, F.Rating, F.Comment FROM FEEDBACK F WHERE F.CID = @CID", con))
                    {
                        da.SelectCommand.Parameters.Add("@CID", SqlDbType.Int).Value = customerId;
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dgvFeedback.DataSource = dt;
                    }
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show($"An unexpected error occurred while refreshing the table: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }








        private void btnUpdate_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    // Validation
                    if (string.IsNullOrWhiteSpace(txtEmail.Text) ||
                        string.IsNullOrWhiteSpace(txtMealId.Text) ||
                        string.IsNullOrWhiteSpace(txtRating.Text))
                    {
                        MessageBox.Show("All fields are required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    if (!int.TryParse(txtMealId.Text, out int mealId) || mealId <= 0)
                    {
                        MessageBox.Show("Please enter a valid Meal ID.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    if (!int.TryParse(txtRating.Text, out int rating) || rating < 1 || rating > 5)
                    {
                        MessageBox.Show("Please enter a valid rating (1-5).", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    using (SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=app;Integrated Security=True"))
                    {
                        con.Open();

                        // Check if MealID exists
                        using (SqlCommand checkMealCmd = new SqlCommand("SELECT COUNT(*) FROM Meal WHERE MealID = @MealID", con))
                        {
                            checkMealCmd.Parameters.Add("@MealID", SqlDbType.Int).Value = mealId;
                            int mealCount = (int)checkMealCmd.ExecuteScalar();
                            if (mealCount == 0)
                            {
                                MessageBox.Show("The Meal ID does not exist. Please enter a valid Meal ID.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }

                        // Get CustomerID from email
                        int customerId;
                        using (SqlCommand getCustomerCmd = new SqlCommand("SELECT CID FROM CUSTOMER WHERE EMAIL = @Email", con))
                        {
                            getCustomerCmd.Parameters.Add("@Email", SqlDbType.NVarChar).Value = txtEmail.Text;
                            object result = getCustomerCmd.ExecuteScalar();

                            if (result == null)
                            {
                                MessageBox.Show("Invalid email. Please use a registered email.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }

                            customerId = Convert.ToInt32(result);
                        }

                        // Update the feedback
                        using (SqlCommand updateCmd = new SqlCommand(
                            "UPDATE FEEDBACK SET Rating = @Rating, Comment = @Comment WHERE CID = @CID AND MealID = @MealID", con))
                        {
                            updateCmd.Parameters.Add("@Rating", SqlDbType.Int).Value = rating;
                            updateCmd.Parameters.Add("@Comment", SqlDbType.NVarChar).Value = txtComment.Text ?? (object)DBNull.Value;
                            updateCmd.Parameters.Add("@CID", SqlDbType.Int).Value = customerId;
                            updateCmd.Parameters.Add("@MealID", SqlDbType.Int).Value = mealId;

                            int rowsAffected = updateCmd.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Feedback updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                // Call the refresh method here
                                RefreshTable(customerId);
                            }
                            else
                            {
                                MessageBox.Show("No matching feedback found to update.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred while updating feedback: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void RefreshTable(int customerId)
        {
            try
            {
                if (DesignMode) return;

                using (SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=app;Integrated Security=True"))
                {
                    con.Open();

                    using (SqlDataAdapter da = new SqlDataAdapter(
                        "SELECT F.MealID, F.Rating, F.Comment FROM FEEDBACK F WHERE F.CID = @CID", con))
                    {
                        da.SelectCommand.Parameters.Add("@CID", SqlDbType.Int).Value = customerId;
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dgvFeedback.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while refreshing the feedback table: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }

}


