﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Food_Ordering_Details
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void btnDeleteFeedback_Click(object sender, EventArgs e)
        {
            // 1. Validate input is provided
            if (string.IsNullOrWhiteSpace(txtFeedbackID.Text))
            {
                MessageBox.Show("Please enter a Feedback ID.", "Input Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 2. Validate numeric value
            if (!int.TryParse(txtFeedbackID.Text.Trim(), out int feedbackId) || feedbackId <= 0)
            {
                MessageBox.Show("Feedback ID must be a positive number.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                using (SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=app;Integrated Security=True"))
                {
                    con.Open();

                    // 3. Check if Feedback ID exists
                    using (SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM Feedback WHERE FeedbackID = @FeedbackID", con))
                    {
                        checkCmd.Parameters.AddWithValue("@FeedbackID", feedbackId);
                        int exists = (int)checkCmd.ExecuteScalar();

                        if (exists == 0)
                        {
                            MessageBox.Show("No feedback found with the given Feedback ID.", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }
                    }

                    // 4. Confirm deletion
                    DialogResult confirm = MessageBox.Show(
                        "Are you sure you want to permanently delete this feedback?",
                        "Confirm Deletion",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Warning);

                    if (confirm != DialogResult.Yes)
                        return;

                    // 5. Perform deletion
                    using (SqlCommand deleteCmd = new SqlCommand("DELETE FROM Feedback WHERE FeedbackID = @FeedbackID", con))
                    {
                        deleteCmd.Parameters.AddWithValue("@FeedbackID", feedbackId);
                        int rowsAffected = deleteCmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Feedback deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            txtFeedbackID.Clear();
                            this.Close(); // Optionally close the form
                        }
                        else
                        {
                            MessageBox.Show("Deletion failed. No rows were affected.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                MessageBox.Show($"SQL Error: {sqlEx.Message}", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Unexpected error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
    }

