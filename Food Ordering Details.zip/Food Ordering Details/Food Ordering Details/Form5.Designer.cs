﻿namespace Food_Ordering_Details
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtFeedbackID = new System.Windows.Forms.TextBox();
            this.btnDeleteFeedback = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(32, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(640, 22);
            this.label1.TabIndex = 1;
            this.label1.Text = "PLEASE ENTER THE FEEDBACKID THAT YOU WANT TO DELETE ";
            // 
            // txtFeedbackID
            // 
            this.txtFeedbackID.Location = new System.Drawing.Point(733, 34);
            this.txtFeedbackID.Name = "txtFeedbackID";
            this.txtFeedbackID.Size = new System.Drawing.Size(202, 22);
            this.txtFeedbackID.TabIndex = 2;
            // 
            // btnDeleteFeedback
            // 
            this.btnDeleteFeedback.BackColor = System.Drawing.Color.Silver;
            this.btnDeleteFeedback.Location = new System.Drawing.Point(258, 136);
            this.btnDeleteFeedback.Name = "btnDeleteFeedback";
            this.btnDeleteFeedback.Size = new System.Drawing.Size(364, 83);
            this.btnDeleteFeedback.TabIndex = 3;
            this.btnDeleteFeedback.Text = "DELETE";
            this.btnDeleteFeedback.UseVisualStyleBackColor = false;
            this.btnDeleteFeedback.Click += new System.EventHandler(this.btnDeleteFeedback_Click);
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Bisque;
            this.ClientSize = new System.Drawing.Size(1406, 547);
            this.Controls.Add(this.btnDeleteFeedback);
            this.Controls.Add(this.txtFeedbackID);
            this.Controls.Add(this.label1);
            this.Name = "Form5";
            this.Text = "Form5";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtFeedbackID;
        private System.Windows.Forms.Button btnDeleteFeedback;
    }
}