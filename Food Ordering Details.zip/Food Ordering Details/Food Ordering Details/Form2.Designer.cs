﻿namespace Food_Ordering_Details
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.foodorderingsystemDataSet = new Food_Ordering_Details.FoodorderingsystemDataSet();
            this.mENUBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mENUTableAdapter = new Food_Ordering_Details.FoodorderingsystemDataSetTableAdapters.MENUTableAdapter();
            this.foodorderingsystemDataSet1 = new Food_Ordering_Details.FoodorderingsystemDataSet1();
            this.mEALBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mEALTableAdapter = new Food_Ordering_Details.FoodorderingsystemDataSet1TableAdapters.MEALTableAdapter();
            this.foodorderingsystemDataSet2 = new Food_Ordering_Details.FoodorderingsystemDataSet2();
            this.mEALBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.mEALTableAdapter1 = new Food_Ordering_Details.FoodorderingsystemDataSet2TableAdapters.MEALTableAdapter();
            this.foodorderingsystemDataSet3 = new Food_Ordering_Details.FoodorderingsystemDataSet3();
            this.fEEDBACKBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fEEDBACKTableAdapter = new Food_Ordering_Details.FoodorderingsystemDataSet3TableAdapters.FEEDBACKTableAdapter();
            this.foodorderingsystemDataSet4 = new Food_Ordering_Details.FoodorderingsystemDataSet4();
            this.fEEDBACKBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.fEEDBACKTableAdapter1 = new Food_Ordering_Details.FoodorderingsystemDataSet4TableAdapters.FEEDBACKTableAdapter();
            this.txtComment = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.fEEDBACKBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.foodorderingsystemDataSet5 = new Food_Ordering_Details.FoodorderingsystemDataSet5();
            this.fEEDBACKTableAdapter2 = new Food_Ordering_Details.FoodorderingsystemDataSet5TableAdapters.FEEDBACKTableAdapter();
            this.btnInsert = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.btnShow = new System.Windows.Forms.Button();
            this.appDataSet = new Food_Ordering_Details.appDataSet();
            this.appDataSet1 = new Food_Ordering_Details.appDataSet1();
            this.appDataSet2 = new Food_Ordering_Details.appDataSet2();
            this.feedbackBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.appDataSet6 = new Food_Ordering_Details.appDataSet6();
            this.feedbackBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.appDataSet5 = new Food_Ordering_Details.appDataSet5();
            this.feedbackTableAdapter3 = new Food_Ordering_Details.appDataSet5TableAdapters.FeedbackTableAdapter();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtMealId = new System.Windows.Forms.TextBox();
            this.txtRating = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.feedbackTableAdapter4 = new Food_Ordering_Details.appDataSet6TableAdapters.FeedbackTableAdapter();
            this.appDataSet7 = new Food_Ordering_Details.appDataSet7();
            this.feedbackBindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.feedbackTableAdapter5 = new Food_Ordering_Details.appDataSet7TableAdapters.FeedbackTableAdapter();
            this.dgvFeedback = new System.Windows.Forms.DataGridView();
            this.appDataSet8 = new Food_Ordering_Details.appDataSet8();
            this.feedbackBindingSource6 = new System.Windows.Forms.BindingSource(this.components);
            this.feedbackTableAdapter6 = new Food_Ordering_Details.appDataSet8TableAdapters.FeedbackTableAdapter();
            this.mealIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.feedbackIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ratingDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.commentDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mENUBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mEALBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mEALBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fEEDBACKBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fEEDBACKBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fEEDBACKBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.feedbackBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appDataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.feedbackBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appDataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.feedbackBindingSource5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFeedback)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appDataSet8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.feedbackBindingSource6)).BeginInit();
            this.SuspendLayout();
            // 
            // foodorderingsystemDataSet
            // 
            this.foodorderingsystemDataSet.DataSetName = "FoodorderingsystemDataSet";
            this.foodorderingsystemDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // mENUBindingSource
            // 
            this.mENUBindingSource.DataMember = "MENU";
            this.mENUBindingSource.DataSource = this.foodorderingsystemDataSet;
            // 
            // mENUTableAdapter
            // 
            this.mENUTableAdapter.ClearBeforeFill = true;
            // 
            // foodorderingsystemDataSet1
            // 
            this.foodorderingsystemDataSet1.DataSetName = "FoodorderingsystemDataSet1";
            this.foodorderingsystemDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // mEALBindingSource
            // 
            this.mEALBindingSource.DataMember = "MEAL";
            this.mEALBindingSource.DataSource = this.foodorderingsystemDataSet1;
            // 
            // mEALTableAdapter
            // 
            this.mEALTableAdapter.ClearBeforeFill = true;
            // 
            // foodorderingsystemDataSet2
            // 
            this.foodorderingsystemDataSet2.DataSetName = "FoodorderingsystemDataSet2";
            this.foodorderingsystemDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // mEALBindingSource1
            // 
            this.mEALBindingSource1.DataMember = "MEAL";
            this.mEALBindingSource1.DataSource = this.foodorderingsystemDataSet2;
            // 
            // mEALTableAdapter1
            // 
            this.mEALTableAdapter1.ClearBeforeFill = true;
            // 
            // foodorderingsystemDataSet3
            // 
            this.foodorderingsystemDataSet3.DataSetName = "FoodorderingsystemDataSet3";
            this.foodorderingsystemDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // fEEDBACKBindingSource
            // 
            this.fEEDBACKBindingSource.DataMember = "FEEDBACK";
            this.fEEDBACKBindingSource.DataSource = this.foodorderingsystemDataSet3;
            // 
            // fEEDBACKTableAdapter
            // 
            this.fEEDBACKTableAdapter.ClearBeforeFill = true;
            // 
            // foodorderingsystemDataSet4
            // 
            this.foodorderingsystemDataSet4.DataSetName = "FoodorderingsystemDataSet4";
            this.foodorderingsystemDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // fEEDBACKBindingSource1
            // 
            this.fEEDBACKBindingSource1.DataMember = "FEEDBACK";
            this.fEEDBACKBindingSource1.DataSource = this.foodorderingsystemDataSet4;
            // 
            // fEEDBACKTableAdapter1
            // 
            this.fEEDBACKTableAdapter1.ClearBeforeFill = true;
            // 
            // txtComment
            // 
            this.txtComment.Location = new System.Drawing.Point(276, 125);
            this.txtComment.Multiline = true;
            this.txtComment.Name = "txtComment";
            this.txtComment.Size = new System.Drawing.Size(233, 80);
            this.txtComment.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(49, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 30);
            this.label1.TabIndex = 6;
            this.label1.Text = "RATING";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Modern No. 20", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(49, 150);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(149, 30);
            this.label2.TabIndex = 7;
            this.label2.Text = "COMMENT";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(383, 189);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 16);
            this.label4.TabIndex = 9;
            // 
            // fEEDBACKBindingSource2
            // 
            this.fEEDBACKBindingSource2.DataMember = "FEEDBACK";
            this.fEEDBACKBindingSource2.DataSource = this.foodorderingsystemDataSet5;
            // 
            // foodorderingsystemDataSet5
            // 
            this.foodorderingsystemDataSet5.DataSetName = "FoodorderingsystemDataSet5";
            this.foodorderingsystemDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // fEEDBACKTableAdapter2
            // 
            this.fEEDBACKTableAdapter2.ClearBeforeFill = true;
            // 
            // btnInsert
            // 
            this.btnInsert.BackColor = System.Drawing.SystemColors.HighlightText;
            this.btnInsert.Location = new System.Drawing.Point(108, 486);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(150, 42);
            this.btnInsert.TabIndex = 18;
            this.btnInsert.Text = "INSERT";
            this.btnInsert.UseVisualStyleBackColor = false;
            this.btnInsert.Click += new System.EventHandler(this.btnInsert_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.SystemColors.HighlightText;
            this.btnUpdate.Location = new System.Drawing.Point(403, 486);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(150, 42);
            this.btnUpdate.TabIndex = 19;
            this.btnUpdate.Text = "UPDATE";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.SystemColors.HighlightText;
            this.button8.Location = new System.Drawing.Point(730, 486);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(148, 42);
            this.button8.TabIndex = 20;
            this.button8.Text = "DELETE";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // btnShow
            // 
            this.btnShow.BackColor = System.Drawing.Color.White;
            this.btnShow.Location = new System.Drawing.Point(1080, 486);
            this.btnShow.Name = "btnShow";
            this.btnShow.Size = new System.Drawing.Size(148, 42);
            this.btnShow.TabIndex = 21;
            this.btnShow.Text = "SHOW DATA";
            this.btnShow.UseVisualStyleBackColor = false;
            this.btnShow.Click += new System.EventHandler(this.btnShow_Click);
            // 
            // appDataSet
            // 
            this.appDataSet.DataSetName = "appDataSet";
            this.appDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // appDataSet1
            // 
            this.appDataSet1.DataSetName = "appDataSet1";
            this.appDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // appDataSet2
            // 
            this.appDataSet2.DataSetName = "appDataSet2";
            this.appDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // feedbackBindingSource4
            // 
            this.feedbackBindingSource4.DataMember = "Feedback";
            this.feedbackBindingSource4.DataSource = this.appDataSet6;
            // 
            // appDataSet6
            // 
            this.appDataSet6.DataSetName = "appDataSet6";
            this.appDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // feedbackBindingSource3
            // 
            this.feedbackBindingSource3.DataMember = "Feedback";
            this.feedbackBindingSource3.DataSource = this.appDataSet5;
            // 
            // appDataSet5
            // 
            this.appDataSet5.DataSetName = "appDataSet5";
            this.appDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // feedbackTableAdapter3
            // 
            this.feedbackTableAdapter3.ClearBeforeFill = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(181, 326);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 16);
            this.label3.TabIndex = 25;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(50, 333);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 22);
            this.label5.TabIndex = 26;
            this.label5.Text = "MEALID";
            // 
            // txtMealId
            // 
            this.txtMealId.Location = new System.Drawing.Point(276, 335);
            this.txtMealId.Name = "txtMealId";
            this.txtMealId.Size = new System.Drawing.Size(137, 22);
            this.txtMealId.TabIndex = 27;
            // 
            // txtRating
            // 
            this.txtRating.Location = new System.Drawing.Point(276, 35);
            this.txtRating.Name = "txtRating";
            this.txtRating.Size = new System.Drawing.Size(137, 22);
            this.txtRating.TabIndex = 28;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(276, 261);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(137, 22);
            this.txtEmail.TabIndex = 29;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.Location = new System.Drawing.Point(50, 261);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(77, 22);
            this.lblEmail.TabIndex = 30;
            this.lblEmail.Text = "EMAIL";
            // 
            // feedbackTableAdapter4
            // 
            this.feedbackTableAdapter4.ClearBeforeFill = true;
            // 
            // appDataSet7
            // 
            this.appDataSet7.DataSetName = "appDataSet7";
            this.appDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // feedbackBindingSource5
            // 
            this.feedbackBindingSource5.DataMember = "Feedback";
            this.feedbackBindingSource5.DataSource = this.appDataSet7;
            // 
            // feedbackTableAdapter5
            // 
            this.feedbackTableAdapter5.ClearBeforeFill = true;
            // 
            // dgvFeedback
            // 
            this.dgvFeedback.AutoGenerateColumns = false;
            this.dgvFeedback.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFeedback.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.mealIDDataGridViewTextBoxColumn,
            this.feedbackIDDataGridViewTextBoxColumn,
            this.cIDDataGridViewTextBoxColumn,
            this.ratingDataGridViewTextBoxColumn,
            this.commentDataGridViewTextBoxColumn});
            this.dgvFeedback.DataSource = this.feedbackBindingSource6;
            this.dgvFeedback.Location = new System.Drawing.Point(581, 26);
            this.dgvFeedback.Name = "dgvFeedback";
            this.dgvFeedback.RowHeadersWidth = 51;
            this.dgvFeedback.RowTemplate.Height = 24;
            this.dgvFeedback.Size = new System.Drawing.Size(702, 244);
            this.dgvFeedback.TabIndex = 31;
            // 
            // appDataSet8
            // 
            this.appDataSet8.DataSetName = "appDataSet8";
            this.appDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // feedbackBindingSource6
            // 
            this.feedbackBindingSource6.DataMember = "Feedback";
            this.feedbackBindingSource6.DataSource = this.appDataSet8;
            // 
            // feedbackTableAdapter6
            // 
            this.feedbackTableAdapter6.ClearBeforeFill = true;
            // 
            // mealIDDataGridViewTextBoxColumn
            // 
            this.mealIDDataGridViewTextBoxColumn.DataPropertyName = "MealID";
            this.mealIDDataGridViewTextBoxColumn.HeaderText = "MealID";
            this.mealIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.mealIDDataGridViewTextBoxColumn.Name = "mealIDDataGridViewTextBoxColumn";
            this.mealIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // feedbackIDDataGridViewTextBoxColumn
            // 
            this.feedbackIDDataGridViewTextBoxColumn.DataPropertyName = "FeedbackID";
            this.feedbackIDDataGridViewTextBoxColumn.HeaderText = "FeedbackID";
            this.feedbackIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.feedbackIDDataGridViewTextBoxColumn.Name = "feedbackIDDataGridViewTextBoxColumn";
            this.feedbackIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.feedbackIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // cIDDataGridViewTextBoxColumn
            // 
            this.cIDDataGridViewTextBoxColumn.DataPropertyName = "CID";
            this.cIDDataGridViewTextBoxColumn.HeaderText = "CID";
            this.cIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.cIDDataGridViewTextBoxColumn.Name = "cIDDataGridViewTextBoxColumn";
            this.cIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // ratingDataGridViewTextBoxColumn
            // 
            this.ratingDataGridViewTextBoxColumn.DataPropertyName = "Rating";
            this.ratingDataGridViewTextBoxColumn.HeaderText = "Rating";
            this.ratingDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.ratingDataGridViewTextBoxColumn.Name = "ratingDataGridViewTextBoxColumn";
            this.ratingDataGridViewTextBoxColumn.Width = 125;
            // 
            // commentDataGridViewTextBoxColumn
            // 
            this.commentDataGridViewTextBoxColumn.DataPropertyName = "Comment";
            this.commentDataGridViewTextBoxColumn.HeaderText = "Comment";
            this.commentDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.commentDataGridViewTextBoxColumn.Name = "commentDataGridViewTextBoxColumn";
            this.commentDataGridViewTextBoxColumn.Width = 125;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1339, 642);
            this.Controls.Add(this.dgvFeedback);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.txtRating);
            this.Controls.Add(this.txtMealId);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnShow);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnInsert);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtComment);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mENUBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mEALBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mEALBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fEEDBACKBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fEEDBACKBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fEEDBACKBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodorderingsystemDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.feedbackBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appDataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.feedbackBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appDataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.feedbackBindingSource5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFeedback)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appDataSet8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.feedbackBindingSource6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private FoodorderingsystemDataSet foodorderingsystemDataSet;
        private System.Windows.Forms.BindingSource mENUBindingSource;
        private FoodorderingsystemDataSetTableAdapters.MENUTableAdapter mENUTableAdapter;
        private FoodorderingsystemDataSet1 foodorderingsystemDataSet1;
        private System.Windows.Forms.BindingSource mEALBindingSource;
        private FoodorderingsystemDataSet1TableAdapters.MEALTableAdapter mEALTableAdapter;
        private FoodorderingsystemDataSet2 foodorderingsystemDataSet2;
        private System.Windows.Forms.BindingSource mEALBindingSource1;
        private FoodorderingsystemDataSet2TableAdapters.MEALTableAdapter mEALTableAdapter1;
        private FoodorderingsystemDataSet3 foodorderingsystemDataSet3;
        private System.Windows.Forms.BindingSource fEEDBACKBindingSource;
        private FoodorderingsystemDataSet3TableAdapters.FEEDBACKTableAdapter fEEDBACKTableAdapter;
        private FoodorderingsystemDataSet4 foodorderingsystemDataSet4;
        private System.Windows.Forms.BindingSource fEEDBACKBindingSource1;
        private FoodorderingsystemDataSet4TableAdapters.FEEDBACKTableAdapter fEEDBACKTableAdapter1;
        private System.Windows.Forms.TextBox txtComment;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private FoodorderingsystemDataSet5 foodorderingsystemDataSet5;
        private System.Windows.Forms.BindingSource fEEDBACKBindingSource2;
        private FoodorderingsystemDataSet5TableAdapters.FEEDBACKTableAdapter fEEDBACKTableAdapter2;
        private System.Windows.Forms.Button btnInsert;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button btnShow;
        private appDataSet appDataSet;
        private appDataSet1 appDataSet1;
        private appDataSet2 appDataSet2;
        private appDataSet5 appDataSet5;
        private System.Windows.Forms.BindingSource feedbackBindingSource3;
        private appDataSet5TableAdapters.FeedbackTableAdapter feedbackTableAdapter3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtMealId;
        private System.Windows.Forms.TextBox txtRating;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblEmail;
        private appDataSet6 appDataSet6;
        private System.Windows.Forms.BindingSource feedbackBindingSource4;
        private appDataSet6TableAdapters.FeedbackTableAdapter feedbackTableAdapter4;
        private appDataSet7 appDataSet7;
        private System.Windows.Forms.BindingSource feedbackBindingSource5;
        private appDataSet7TableAdapters.FeedbackTableAdapter feedbackTableAdapter5;
        private System.Windows.Forms.DataGridView dgvFeedback;
        private appDataSet8 appDataSet8;
        private System.Windows.Forms.BindingSource feedbackBindingSource6;
        private appDataSet8TableAdapters.FeedbackTableAdapter feedbackTableAdapter6;
        private System.Windows.Forms.DataGridViewTextBoxColumn mealIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn feedbackIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ratingDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn commentDataGridViewTextBoxColumn;
    }
}